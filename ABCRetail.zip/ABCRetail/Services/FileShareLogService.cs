﻿using Azure;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using Microsoft.Extensions.Options;
using System.Text;
namespace ABCRetail.Services

{
    public class FileShareLogService
    {
        private readonly ShareClient _share;

        public FileShareLogService(ShareServiceClient ssc, IOptions<AzureNames> names)
        {
            _share = ssc.GetShareClient(names.Value.FileShareName);
            _share.CreateIfNotExists();
        }

        public async Task<string> WriteLogAsync(string text)
        {
            var dir = _share.GetRootDirectoryClient();
            await dir.CreateIfNotExistsAsync();

            string fileName = $"log-{DateTime.UtcNow:yyyy-MM-dd-HHmmss}.txt";
            var file = dir.GetFileClient(fileName);

            byte[] bytes = Encoding.UTF8.GetBytes(text);
            await file.CreateAsync(bytes.Length);
            using var ms = new MemoryStream(bytes);
            await file.UploadRangeAsync(new HttpRange(0, bytes.Length), ms);
            return fileName;
        }

        public async IAsyncEnumerable<ShareFileItem> ListLogsAsync()
        {
            var dir = _share.GetRootDirectoryClient();
            await foreach (var item in dir.GetFilesAndDirectoriesAsync())
            {
                if (!item.IsDirectory) yield return item;
            }
        }

        public async Task<Stream> DownloadAsync(string fileName)
        {
            var dir = _share.GetRootDirectoryClient();
            var file = dir.GetFileClient(fileName);
            var dl = await file.DownloadAsync();
            return dl.Value.Content;
        }
    }
}
