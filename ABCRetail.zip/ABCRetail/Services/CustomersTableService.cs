﻿using ABCRetail.Models;
using Azure.Data.Tables;
using Microsoft.Extensions.Options;
namespace ABCRetail.Services
{
    public class CustomersTableService
    {
        private readonly HttpClient _http;

        public CustomersTableService(IHttpClientFactory factory)
        {
            _http = factory.CreateClient("AzureFunctions");
        }

        public async Task AddCustomerAsync(CustomerEntity customer)
        {
            var response = await _http.PostAsJsonAsync("StoreCustomerToTable", customer);
            response.EnsureSuccessStatusCode();
        }
    }

}
