﻿using ABCRetail.Models;
using Azure.Data.Tables;
using Microsoft.Extensions.Options;
namespace ABCRetail.Services
{
    public class CustomersTableService
    {
        private readonly TableClient _table;

        public CustomersTableService(TableServiceClient tsc, IOptions<AzureNames> names)
        {
            _table = tsc.GetTableClient(names.Value.CustomersTable);
            _table.CreateIfNotExists();
        }

        public async Task AddAsync(CustomerEntity entity) => await _table.AddEntityAsync(entity);

        public IEnumerable<CustomerEntity> GetAll()
            => _table.Query<CustomerEntity>(x => x.PartitionKey == "CUSTOMER");

        public async Task DeleteAsync(string rowKey)
            => await _table.DeleteEntityAsync("CUSTOMER", rowKey);
    }
}
