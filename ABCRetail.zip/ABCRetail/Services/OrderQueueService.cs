﻿using ABCRetail.Models;
using Azure.Storage.Queues;
using Microsoft.Extensions.Options;
using System.Text.Json;
namespace ABCRetail.Services

{
    public class OrderQueueService
    {
        private readonly QueueClient _queue;

        public OrderQueueService(QueueServiceClient qsc, IOptions<AzureNames> names)
        {
            _queue = qsc.GetQueueClient(names.Value.QueueName);
            _queue.CreateIfNotExists();
        }

        public async Task EnqueueAsync(OrderMessage msg)
        {
            string payload = JsonSerializer.Serialize(msg);
            await _queue.SendMessageAsync(payload);
        }

        public async Task<IEnumerable<string>> PeekAsync(int max = 16)
        {
            var peek = await _queue.PeekMessagesAsync(max);
            return peek.Value.Select(m => m.MessageText);
        }

        // Optional: receive & delete (processing)
        public async Task<int> ReceiveAndDeleteAsync(int max = 10)
        {
            var received = await _queue.ReceiveMessagesAsync(maxMessages: max, visibilityTimeout: TimeSpan.FromSeconds(30));
            int count = 0;
            foreach (var m in received.Value)
            {
                // process m.MessageText if needed
                await _queue.DeleteMessageAsync(m.MessageId, m.PopReceipt);
                count++;
            }
            return count;
        }
    }
}
