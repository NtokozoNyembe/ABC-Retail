﻿using System.Net.Http;
using System.Threading.Tasks;

namespace ABCRetail.Services
{
   
    public class AzureFunctionCaller
    {
        private readonly HttpClient _httpClient;

        public AzureFunctionCaller()
        {
            _httpClient = new HttpClient();
        }

        public async Task<string> CallFunctionAsync(string functionUrl)
        {
            var response = await _httpClient.GetAsync(functionUrl);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }
    }

}
