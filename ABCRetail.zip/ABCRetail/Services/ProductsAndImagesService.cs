﻿using ABCRetail.Models;
using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Options;
namespace ABCRetail.Services

{
    public class ProductsAndImagesService
    {
        private readonly TableClient _products;
        private readonly BlobContainerClient _container;

        public ProductsAndImagesService(
            TableServiceClient tsc, BlobServiceClient bsc, IOptions<AzureNames> names)
        {
            _products = tsc.GetTableClient(names.Value.ProductsTable);
            _products.CreateIfNotExists();

            _container = bsc.GetBlobContainerClient(names.Value.BlobContainer);
             _container.CreateIfNotExists(PublicAccessType.Blob);
        }

        public IEnumerable<ProductEntity> GetAll()
      => _products.Query<ProductEntity>(x => x.PartitionKey == "PRODUCT");

        public async Task AddOrUpdateProductAsync(ProductEntity entity)
            => await _products.UpsertEntityAsync(entity);

        public async Task DeleteAsync(string rowKey)
            => await _products.DeleteEntityAsync("PRODUCT", rowKey);

        public async Task<string> UploadImageAsync(string fileName, Stream content)
        {
            var blob = _container.GetBlobClient(fileName);
            await blob.UploadAsync(content, overwrite: true);
            return blob.Uri.ToString();
        }
    }
}
