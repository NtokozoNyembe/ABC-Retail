﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ABCRetail.Models;

namespace ABCRetail.Services
{
    public class ProductsAndImagesService
    {
        private readonly HttpClient _http;
        private readonly List<ProductEntity> _products = new();

        public IEnumerable<ProductEntity> GetAll()
        {
            return _products;
        }
        public async Task<string> UploadImageAsync(string fileName, System.IO.Stream stream)
        {
            // Later, hook this into Azure Blob Storage
            await Task.Delay(500); // simulate upload delay
            return $"https://fakebloburl/{fileName}";
        }

        // Example method: add or update a product
        public async Task AddOrUpdateProductAsync(ProductEntity product)
        {
            // For now, just add to in-memory list
            _products.Add(product);
            await Task.CompletedTask;
        }

        public ProductsAndImagesService(IHttpClientFactory factory)
        {
            _http = factory.CreateClient("AzureFunctions");
        }

        public async Task UploadImageAsync(IFormFile file)
        {
            using var content = new MultipartFormDataContent();
            content.Add(new StreamContent(file.OpenReadStream()), "file", file.FileName);

            var response = await _http.PostAsync("UploadBlob", content);
            response.EnsureSuccessStatusCode();
        }
    }
}
