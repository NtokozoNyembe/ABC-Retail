﻿using ABCRetail.Models;
using ABCRetail.Services;
using Microsoft.AspNetCore.Mvc;

namespace ABCRetail.Controllers
{
    public class OrdersController : Controller
    {
        public async Task<IActionResult> CallBlobFunction()
        {
            var caller = new AzureFunctionCaller();
            string result = await caller.CallFunctionAsync("<BlobFunctionURL>?code=<yourfunctionkey>");
            ViewBag.Message = result;
            return View();
        }

        private readonly OrderQueueService _queue;
        public OrdersController(OrderQueueService queue) => _queue = queue;

        public async Task<IActionResult> Index()
        {
            var messages = await _queue.PeekAsync(16);
            return View(messages);
        }

        [HttpPost]
        public async Task<IActionResult> Enqueue(string action, string payload)
        {
            await _queue.EnqueueAsync(new OrderMessage { Action = action, Payload = payload });
            return RedirectToAction(nameof(Index));
        }

        // Optional: receive & delete processed messages
        [HttpPost]
        public async Task<IActionResult> Process()
        {
            var count = await _queue.ReceiveAndDeleteAsync(10);
            TempData["Processed"] = count;
            return RedirectToAction(nameof(Index));
        }
    }
}
