﻿using Microsoft.AspNetCore.Mvc;
using ABCRetail.Models;
using ABCRetail.Services;

namespace ABCRetail.Controllers
{

    public class CustomersController : Controller
    {
        private readonly CustomersTableService _svc;
        public CustomersController(CustomersTableService svc) => _svc = svc;

        public IActionResult Index() => View(_svc.GetAll());

        [HttpGet]
        public IActionResult Create() => View(new CustomerEntity());

        [HttpPost]
        public async Task<IActionResult> Create(CustomerEntity model)
        {
            if (!ModelState.IsValid) return View(model);
            await _svc.AddAsync(model);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Delete(string id)
        {
            await _svc.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }

}
