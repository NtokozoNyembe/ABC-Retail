﻿using Microsoft.AspNetCore.Mvc;
using ABCRetail.Models;
using ABCRetail.Services;

namespace ABCRetail.Controllers
{

    public class CustomersController : Controller
    {
        public async Task<IActionResult> CallBlobFunction()
        {
            var caller = new AzureFunctionCaller();
            string result = await caller.CallFunctionAsync("<BlobFunctionURL>?code=<yourfunctionkey>");
            ViewBag.Message = result;
            return View();
        }

        private readonly CustomersTableService _svc;
        public CustomersController(CustomersTableService svc) => _svc = svc;

        public IActionResult Index() => View(_svc.GetAll());

        [HttpGet]
        public IActionResult Create() => View(new CustomerEntity());

        [HttpPost]
        public async Task<IActionResult> Create(CustomerEntity model)
        {
            if (!ModelState.IsValid) return View(model);
            await _svc.AddAsync(model);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Delete(string id)
        {
            await _svc.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }

}
