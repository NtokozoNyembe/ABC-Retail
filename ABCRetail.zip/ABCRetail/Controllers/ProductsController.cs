﻿using Microsoft.AspNetCore.Mvc;
using ABCRetail.Models;
using ABCRetail.Services;

namespace ABCRetail.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductsAndImagesService _svc;
        public ProductsController(ProductsAndImagesService svc) => _svc = svc;

        public IActionResult Index() => View(_svc.GetAll());

        [HttpGet]
        public IActionResult Create() => View(new ProductEntity());

        [HttpPost]
        public async Task<IActionResult> Create(ProductEntity model, IFormFile? image)
        {
            if (!ModelState.IsValid) return View(model);

            if (image != null && image.Length > 0)
            {
                var fileName = $"{Guid.NewGuid()}-{image.FileName}";
                using var s = image.OpenReadStream();
                var url = await _svc.UploadImageAsync(fileName, s);
                model.ImageUrl = url;
            }
            await _svc.AddOrUpdateProductAsync(model);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Delete(string id)
        {
            await _svc.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }

}
