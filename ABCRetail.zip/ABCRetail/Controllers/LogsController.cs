﻿using ABCRetail.Services;
using Microsoft.AspNetCore.Mvc;

namespace ABCRetail.Controllers
{

    public class LogsController : Controller
    {
        public async Task<IActionResult> CallBlobFunction()
        {
            var caller = new AzureFunctionCaller();
            string result = await caller.CallFunctionAsync("<BlobFunctionURL>?code=<yourfunctionkey>");
            ViewBag.Message = result;
            return View();
        }

        private readonly FileShareLogService _logs;
        public LogsController(FileShareLogService logs) => _logs = logs;

        public async Task<IActionResult> Index()
        {
            var items = new List<string>();
            await foreach (var f in _logs.ListLogsAsync())
                items.Add(f.Name);
            return View(items);
        }

        [HttpPost]
        public async Task<IActionResult> Create(string text)
        {
            await _logs.WriteLogAsync(text ?? "Empty log entry");
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> Download(string name)
        {
            var stream = await _logs.DownloadAsync(name);
            return File(stream, "text/plain", name);
        }
    }

}
