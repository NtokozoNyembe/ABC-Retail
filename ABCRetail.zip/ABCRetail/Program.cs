using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;
using ABCRetail.Services;
using Azure;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

builder.Services.AddHttpClient("AzureFunctions", client =>
{
    client.BaseAddress = new Uri("https://your-function-app.azurewebsites.net/api/");
});


// Load config
var cfg = builder.Configuration.GetSection("AzureStorage");
string conn = builder.Configuration.GetConnectionString("AzureStorage")
              ?? throw new InvalidOperationException("Azure Storage connection string not found.");

// Create file share (applogs)
var share = new ShareClient(conn, "applogs");
await share.CreateIfNotExistsAsync();

//  Get root directory
var root = share.GetRootDirectoryClient();

// Get/create subdirectory "logs"
var dir = root.GetSubdirectoryClient("logs");
try
{
    await dir.CreateAsync();
}
catch (Azure.RequestFailedException ex) when (ex.ErrorCode == "ResourceAlreadyExists")
{
    // directory already exists, ignore
}

////  Write a test log file
var file = dir.GetFileClient($"log-{DateTime.UtcNow:yyyyMMddHHmmss}.txt");
byte[] content = Encoding.UTF8.GetBytes("Log line at " + DateTime.Now);

await file.CreateAsync(content.Length);
using (var stream = new MemoryStream(content))
{
    await file.UploadRangeAsync(new HttpRange(0, content.Length), stream);
}

// Register Azure clients
builder.Services.AddSingleton(new TableServiceClient(conn));
builder.Services.AddSingleton(new BlobServiceClient(conn));
builder.Services.AddSingleton(new QueueServiceClient(conn));
builder.Services.AddSingleton(new ShareServiceClient(conn));

// Register options (names)
builder.Services.Configure<AzureNames>(o =>
{
    o.CustomersTable = cfg.GetSection("Tables")["Customers"] ?? "Customers";
    o.ProductsTable = cfg.GetSection("Tables")["Products"] ?? "Products";
    o.BlobContainer = cfg["BlobContainer"] ?? "productimages";
    o.QueueName = cfg["QueueName"] ?? "orderqueue";
    o.FileShareName = cfg["FileShareName"] ?? "applogs";
});

Console.WriteLine($"Azure Storage Connection: {conn}");

// Register our services
builder.Services.AddScoped<CustomersTableService>();
builder.Services.AddScoped<ProductsAndImagesService>();
builder.Services.AddScoped<OrderQueueService>();
builder.Services.AddScoped<FileShareLogService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();


// Helper class
public class AzureNames
{
    public string CustomersTable { get; set; } = "";
    public string ProductsTable { get; set; } = "";
    public string BlobContainer { get; set; } = "";
    public string QueueName { get; set; } = "";
    public string FileShareName { get; set; } = "";
}
