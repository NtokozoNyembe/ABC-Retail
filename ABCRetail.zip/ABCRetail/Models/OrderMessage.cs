﻿//  (simple DTO for queue messages)
namespace ABCRetail.Models
{
    public class OrderMessage
    {
        public string Action { get; set; } = "Processing order";
        public string Payload { get; set; } = "";
    }
}
