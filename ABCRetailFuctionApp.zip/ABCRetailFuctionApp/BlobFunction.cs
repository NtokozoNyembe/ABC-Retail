﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Azure.Storage.Blobs;
using System.Net;

namespace ABCRetailFuctionApp
{
    

    public class BlobFunction
    {
        [Function("UploadToBlob")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            var storageConn = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            var blobServiceClient = new BlobServiceClient(storageConn);
            var containerClient = blobServiceClient.GetBlobContainerClient("uploads");
            await containerClient.CreateIfNotExistsAsync();

            var blobClient = containerClient.GetBlobClient("sample.txt");
            using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes("Hello from MVC App!"));
            await blobClient.UploadAsync(stream, overwrite: true);

            var response = req.CreateResponse(HttpStatusCode.OK);
            await response.WriteStringAsync("File uploaded to Blob Storage ✅");
            return response;
        }
    }

}
