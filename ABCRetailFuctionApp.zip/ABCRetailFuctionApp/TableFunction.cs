﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Azure.Data.Tables;
using System.Net;

namespace ABCRetailFuctionApp
{
    public class TableFunction
    {
        [Function("WriteToTable")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            var storageConn = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            var serviceClient = new TableServiceClient(storageConn);
            var tableClient = serviceClient.GetTableClient("MyTable");
            await tableClient.CreateIfNotExistsAsync();

            var entity = new TableEntity("UserPartition", Guid.NewGuid().ToString())
        {
            { "Info", "Stored from MVC App" },
            { "CreatedDate", DateTime.UtcNow }
        };

            await tableClient.AddEntityAsync(entity);

            var response = req.CreateResponse(HttpStatusCode.OK);
            await response.WriteStringAsync("Entity written to Table Storage ✅");
            return response;
        }
    }

}
