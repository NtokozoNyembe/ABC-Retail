﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Azure.Storage.Files.Shares;
using System.Net;

namespace ABCRetailFuctionApp
{
  

    public class FileShareFunction
    {
        [Function("WriteToFileShare")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            var storageConn = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            var shareClient = new ShareClient(storageConn, "myfiles");
            await shareClient.CreateIfNotExistsAsync();

            var directoryClient = shareClient.GetRootDirectoryClient();
            var fileClient = directoryClient.GetFileClient("sample.txt");

            byte[] data = System.Text.Encoding.UTF8.GetBytes("Hello from MVC App to File Share!");
            using var stream = new MemoryStream(data);

            await fileClient.CreateAsync(stream.Length);
            await fileClient.UploadRangeAsync(new Azure.HttpRange(0, stream.Length), stream);

            var response = req.CreateResponse(HttpStatusCode.OK);
            await response.WriteStringAsync("File written to Azure File Share ✅");
            return response;
        }
    }

}
