﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Azure.Storage.Queues;
using System.Net;

namespace ABCRetailFuctionApp
{
   

    public class QueueFunction
    {
        [Function("WriteToQueue")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            var storageConn = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            var queueClient = new QueueClient(storageConn, "transactions");
            await queueClient.CreateIfNotExistsAsync();

            await queueClient.SendMessageAsync("New transaction created!");

            var response = req.CreateResponse(HttpStatusCode.OK);
            await response.WriteStringAsync("Message written to Queue Storage ✅");
            return response;
        }
    }

}
